# AIR INDIA Airport Management System

Learning/demo project using Java, MVC, Servlets, JDBC, MySQL, HTML, CSS, JavaScript and Maven.

## Features
- Add AIR INDIA flights
- View flights
- Search flights
- Delete flights
- MVC architecture
- JDBC CRUD

## Requirements
- JDK 17+
- MySQL
- Maven
- Apache Tomcat 10.1+

## Setup
1. Run `database.sql` in MySQL.
2. Open `DBConnection.java`.
3. Replace `YOUR_MYSQL_PASSWORD` with your local MySQL password.
4. Run `mvn clean package`.
5. Deploy `target/AirIndiaAirportManagement.war` to Tomcat.
6. Open `http://localhost:8080/AirIndiaAirportManagement/`.

## GitHub security
Do not commit real database passwords or secrets. Use environment variables/configuration for a real deployment.

This project is for educational/demo use and is not connected to Air India's real systems.


## Render deployment

This version includes `Dockerfile` and `render.yaml` for deploying the Java Servlet application on Render.

1. Push the entire project to GitHub.
2. In Render choose **New -> Web Service**.
3. Connect the GitHub repository.
4. Select the **Free** plan if available.
5. Render should detect `Dockerfile` automatically.
6. Deploy.

Important: the current application still uses MySQL. The database connection must be changed from localhost to a reachable hosted database before database features will work on Render.
