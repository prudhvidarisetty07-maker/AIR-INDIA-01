package com.airindia.model;

public class Flight {
    private int id;
    private String flightNumber, airline, source, destination, departureTime, arrivalTime;
    private int totalSeats, availableSeats;

    public Flight() {}

    public Flight(int id, String flightNumber, String airline, String source,
                  String destination, String departureTime, String arrivalTime,
                  int totalSeats, int availableSeats) {
        this.id=id; this.flightNumber=flightNumber; this.airline=airline;
        this.source=source; this.destination=destination;
        this.departureTime=departureTime; this.arrivalTime=arrivalTime;
        this.totalSeats=totalSeats; this.availableSeats=availableSeats;
    }

    public int getId(){return id;} public void setId(int v){id=v;}
    public String getFlightNumber(){return flightNumber;} public void setFlightNumber(String v){flightNumber=v;}
    public String getAirline(){return airline;} public void setAirline(String v){airline=v;}
    public String getSource(){return source;} public void setSource(String v){source=v;}
    public String getDestination(){return destination;} public void setDestination(String v){destination=v;}
    public String getDepartureTime(){return departureTime;} public void setDepartureTime(String v){departureTime=v;}
    public String getArrivalTime(){return arrivalTime;} public void setArrivalTime(String v){arrivalTime=v;}
    public int getTotalSeats(){return totalSeats;} public void setTotalSeats(int v){totalSeats=v;}
    public int getAvailableSeats(){return availableSeats;} public void setAvailableSeats(int v){availableSeats=v;}
}
