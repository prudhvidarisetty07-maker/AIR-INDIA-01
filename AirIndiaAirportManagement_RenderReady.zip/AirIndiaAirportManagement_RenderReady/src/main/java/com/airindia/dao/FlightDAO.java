package com.airindia.dao;

import com.airindia.model.Flight;
import com.airindia.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FlightDAO {
    public boolean addFlight(Flight f) {
        String sql = "INSERT INTO flights(flight_number,airline,source,destination,departure_time,arrival_time,total_seats,available_seats) VALUES(?,?,?,?,?,?,?,?)";
        try (Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,f.getFlightNumber()); p.setString(2,"AIR INDIA"); p.setString(3,f.getSource());
            p.setString(4,f.getDestination()); p.setString(5,f.getDepartureTime()); p.setString(6,f.getArrivalTime());
            p.setInt(7,f.getTotalSeats()); p.setInt(8,f.getAvailableSeats());
            return p.executeUpdate()>0;
        } catch(SQLException e){e.printStackTrace(); return false;}
    }

    public List<Flight> getAllFlights() {
        List<Flight> list=new ArrayList<>();
        String sql="SELECT * FROM flights ORDER BY id DESC";
        try(Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql); ResultSet r=p.executeQuery()){
            while(r.next()) list.add(map(r));
        } catch(SQLException e){e.printStackTrace();}
        return list;
    }

    public List<Flight> searchFlights(String k) {
        List<Flight> list=new ArrayList<>();
        String sql="SELECT * FROM flights WHERE flight_number LIKE ? OR source LIKE ? OR destination LIKE ? ORDER BY id DESC";
        try(Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)){
            String s="%"+k+"%"; p.setString(1,s); p.setString(2,s); p.setString(3,s);
            try(ResultSet r=p.executeQuery()){while(r.next()) list.add(map(r));}
        } catch(SQLException e){e.printStackTrace();}
        return list;
    }

    public boolean updateFlight(Flight f) {
        String sql="UPDATE flights SET flight_number=?,source=?,destination=?,departure_time=?,arrival_time=?,total_seats=?,available_seats=? WHERE id=?";
        try(Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,f.getFlightNumber()); p.setString(2,f.getSource()); p.setString(3,f.getDestination());
            p.setString(4,f.getDepartureTime()); p.setString(5,f.getArrivalTime());
            p.setInt(6,f.getTotalSeats()); p.setInt(7,f.getAvailableSeats()); p.setInt(8,f.getId());
            return p.executeUpdate()>0;
        } catch(SQLException e){e.printStackTrace(); return false;}
    }

    public boolean deleteFlight(int id) {
        try(Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement("DELETE FROM flights WHERE id=?")){
            p.setInt(1,id); return p.executeUpdate()>0;
        } catch(SQLException e){e.printStackTrace(); return false;}
    }

    private Flight map(ResultSet r)throws SQLException{
        Flight f=new Flight();
        f.setId(r.getInt("id")); f.setFlightNumber(r.getString("flight_number"));
        f.setAirline(r.getString("airline")); f.setSource(r.getString("source"));
        f.setDestination(r.getString("destination")); f.setDepartureTime(r.getString("departure_time"));
        f.setArrivalTime(r.getString("arrival_time")); f.setTotalSeats(r.getInt("total_seats"));
        f.setAvailableSeats(r.getInt("available_seats")); return f;
    }
}
