package com.airindia.service;

import com.airindia.dao.FlightDAO;
import com.airindia.model.Flight;
import java.util.List;

public class FlightService {
    private final FlightDAO dao = new FlightDAO();
    public boolean addFlight(Flight f){return dao.addFlight(f);}
    public List<Flight> getAllFlights(){return dao.getAllFlights();}
    public List<Flight> searchFlights(String k){return dao.searchFlights(k);}
    public boolean updateFlight(Flight f){return dao.updateFlight(f);}
    public boolean deleteFlight(int id){return dao.deleteFlight(id);}
}
