package com.airindia.controller;

import com.airindia.model.Flight;
import com.airindia.service.FlightService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/api/flights/*")
public class FlightServlet extends HttpServlet {
    private FlightService service;
    public void init(){service=new FlightService();}

    protected void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException{
        res.setContentType("application/json"); res.setCharacterEncoding("UTF-8");
        String k=req.getParameter("search");
        List<Flight> fs=(k!=null)?service.searchFlights(k):service.getAllFlights();
        PrintWriter o=res.getWriter(); o.print("[");
        for(int i=0;i<fs.size();i++){
            Flight f=fs.get(i);
            o.print("{"id":"+f.getId()+","flightNumber":""+esc(f.getFlightNumber())+
                    "","airline":""+esc(f.getAirline())+"","source":""+esc(f.getSource())+
                    "","destination":""+esc(f.getDestination())+"","departureTime":""+esc(f.getDepartureTime())+
                    "","arrivalTime":""+esc(f.getArrivalTime())+"","totalSeats":"+f.getTotalSeats()+
                    ","availableSeats":"+f.getAvailableSeats()+"}");
            if(i<fs.size()-1)o.print(",");
        } o.print("]");
    }

    protected void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException{
        send(res,service.addFlight(read(req)));
    }

    protected void doDelete(HttpServletRequest req,HttpServletResponse res)throws IOException{
        send(res,service.deleteFlight(Integer.parseInt(req.getParameter("id"))));
    }

    private Flight read(HttpServletRequest r){
        Flight f=new Flight();
        f.setFlightNumber(r.getParameter("flightNumber")); f.setAirline("AIR INDIA");
        f.setSource(r.getParameter("source")); f.setDestination(r.getParameter("destination"));
        f.setDepartureTime(r.getParameter("departureTime")); f.setArrivalTime(r.getParameter("arrivalTime"));
        f.setTotalSeats(Integer.parseInt(r.getParameter("totalSeats")));
        f.setAvailableSeats(Integer.parseInt(r.getParameter("availableSeats")));
        return f;
    }
    private void send(HttpServletResponse r,boolean ok)throws IOException{
        r.setContentType("application/json"); r.getWriter().print("{"success":"+ok+"}");
    }
    private String esc(String s){return s==null?"":s.replace("\","\\").replace(""","\"");}
}
