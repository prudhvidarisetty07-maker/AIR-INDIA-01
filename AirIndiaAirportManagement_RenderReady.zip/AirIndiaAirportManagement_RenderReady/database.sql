CREATE DATABASE IF NOT EXISTS airindia_db;
USE airindia_db;

CREATE TABLE flights (
    id INT PRIMARY KEY AUTO_INCREMENT,
    flight_number VARCHAR(20) NOT NULL,
    airline VARCHAR(100) NOT NULL DEFAULT 'AIR INDIA',
    source VARCHAR(100) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    departure_time DATETIME NOT NULL,
    arrival_time DATETIME NOT NULL,
    total_seats INT NOT NULL,
    available_seats INT NOT NULL
);

INSERT INTO flights
(flight_number, airline, source, destination, departure_time, arrival_time, total_seats, available_seats)
VALUES
('AI101','AIR INDIA','Delhi','Mumbai','2026-10-05 08:00:00','2026-10-05 10:15:00',180,180),
('AI202','AIR INDIA','Hyderabad','Delhi','2026-10-05 11:00:00','2026-10-05 13:20:00',180,175),
('AI303','AIR INDIA','Mumbai','Bengaluru','2026-10-06 15:00:00','2026-10-06 16:45:00',180,160);
